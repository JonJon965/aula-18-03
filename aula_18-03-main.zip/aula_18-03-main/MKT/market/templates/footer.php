</main>

<footer>
    <p>&copy; <?php echo date("Y"); ?> Marketplace</p>
</footer>

</body>
</html>
