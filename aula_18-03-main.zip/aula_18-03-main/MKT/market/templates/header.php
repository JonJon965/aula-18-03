<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marketplace</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<header>
    <h1>Marketplace</h1>
    <nav>
        <ul>
            <li><a href="../pages/index.php">Home</a></li>
            <li><a href="../pages/cart.php">Carrinho</a></li>
        </ul>
    </nav>
</header>

<main>
