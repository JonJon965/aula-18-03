<?php
// Arquivo: arquivo_incluido.php
$mensagem = "Este é um arquivo incluído usando require.";
?>
