<!-- functions.php -->
<?php
function calcularSoma($a, $b) {
    return $a + $b;
}
?>
