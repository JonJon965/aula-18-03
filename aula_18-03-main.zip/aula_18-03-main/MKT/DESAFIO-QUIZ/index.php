<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Quiz - Página Inicial</title>
</head>
<body>
    <h2>Bem-vindo ao Quiz!</h2>
    <form action="quiz.php" method="post">
        <label for="nome">Digite seu nome:</label>
        <input type="text" id="nome" name="nome" required>
        <button type="submit">Iniciar Quiz</button>
    </form>
</body>
</html>
