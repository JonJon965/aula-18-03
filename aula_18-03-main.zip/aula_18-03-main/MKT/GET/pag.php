<?php
$nome = $_GET["cxnome"];
echo "Nome: " . $nome;
?>
