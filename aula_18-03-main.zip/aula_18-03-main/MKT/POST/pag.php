<?php
$nome = $_POST["cxnome"];
echo "Nome: " . $nome;
?>

